from Build_Classifier import *
import tensorflow as tf
import numpy as np
import os, argparse, glob
import sys
import cv2


# ------ Training ------#
class Classifier(object):

    def __init__(self, train_path, batch_size):

        def load_classes(train_path):
            classes = []
            path = os.path.join(train_path, '*')
            files = glob.glob(path)
            for f in files:
                classes.append(f[len(train_path) + 1:])
            return classes

        # ------ Set Variables ------ #
        batch_size = 32
        self.batch_size = batch_size
        total_iterations = 0
        self.total_iterations = total_iterations

        # Prepare input data
        classes = load_classes(train_path)
        self.classes = classes

        num_classes = len(self.classes)
        self.num_classes = num_classes

        # 20% of the data will automatically be used for validation
        validation_size = 0.2
        self.validation_size = validation_size

        img_size = 128
        self.img_size = img_size

        num_channels = 3
        self.num_channels = num_channels

        train_path = 'cat-dog-training_data'
        self.train_path = train_path

        test_path = 'testing_data'
        self.test_path = test_path

        # We shall load all the training and validation images, and labels into memory using openCV, and use that during training
        data = read_train_sets(self.train_path, self.img_size, self.classes, self.validation_size)
        self.data = data

        print("Complete reading input data. Will Now print a snippet of it")
        print("Number of files in Training-set:\t\t{}".format(len(data.train.labels)))
        print("Number of files in Validation-set:\t{}".format(len(data.valid.labels)))

    def train(self, num_iteration):
        session = tf.Session()
        x = tf.placeholder(tf.float32, shape=[None, self.img_size, self.img_size, self.num_channels], name='x')

        # labels
        y_true = tf.placeholder(tf.float32, shape=[None, self.num_classes], name='y_true')
        y_true_cls = tf.argmax(y_true, dimension=1)

        # Network graph params
        filter_size_conv1 = 3
        num_filters_conv1 = 32

        filter_size_conv2 = 3
        num_filters_conv2 = 32

        filter_size_conv3 = 3
        num_filters_conv3 = 64

        fc_layer_size = 128

        # ------ Using Layer Outputs - Build Layers ------ #
        layer_conv1 = create_convolutional_layer(input=x, num_input_channels=self.num_channels, conv_filter_size=filter_size_conv1, num_filters=num_filters_conv1)

        layer_conv2 = create_convolutional_layer(input=layer_conv1, num_input_channels=num_filters_conv1, conv_filter_size=filter_size_conv2, num_filters=num_filters_conv2)

        layer_conv3 = create_convolutional_layer(input=layer_conv2, num_input_channels=num_filters_conv2, conv_filter_size=filter_size_conv3, num_filters=num_filters_conv3)

        layer_flat = create_flatten_layer(layer_conv3)

        layer_fc1 = create_fc_layer(input=layer_flat, num_inputs=layer_flat.get_shape()[1:4].num_elements(), num_outputs=fc_layer_size, use_relu=True)

        layer_fc2 = create_fc_layer(input=layer_fc1, num_inputs=fc_layer_size, num_outputs=self.num_classes, use_relu=False)

        y_pred = tf.nn.softmax(layer_fc2, name='y_pred')

        y_pred_cls = tf.argmax(y_pred, dimension=1)

        session.run(tf.global_variables_initializer())
        cross_entropy = tf.nn.softmax_cross_entropy_with_logits(logits=layer_fc2, labels=y_true)
        cost = tf.reduce_mean(cross_entropy)
        optimizer = tf.train.AdamOptimizer(learning_rate=1e-4).minimize(cost)
        correct_prediction = tf.equal(y_pred_cls, y_true_cls)
        accuracy = tf.reduce_mean(tf.cast(correct_prediction, tf.float32))
        session.run(tf.global_variables_initializer())
        saver = tf.train.Saver()
        train_batch_size = self.batch_size

        for i in range(self.total_iterations, self.total_iterations + num_iteration):

            x_batch, y_true_batch, _, cls_batch = self.data.train.next_batch(self.batch_size)
            x_valid_batch, y_valid_batch, _, valid_cls_batch = self.data.valid.next_batch(self.batch_size)

            feed_dict_tr = {x: x_batch, y_true: y_true_batch}
            feed_dict_val = {x: x_valid_batch, y_true: y_valid_batch}

            session.run(optimizer, feed_dict=feed_dict_tr)

            if i % int(self.data.train.num_examples / self.batch_size) == 0:
                val_loss = session.run(cost, feed_dict=feed_dict_val)
                epoch = int(i / int(self.data.train.num_examples / self.batch_size))

                # def show_progress(self, epoch, feed_dict_train, feed_dict_validate, val_loss):
                acc = session.run(accuracy, feed_dict=feed_dict_tr)
                val_acc = session.run(accuracy, feed_dict=feed_dict_val)
                msg = "Training Epoch {0} - Training Accuracy: {1:>6.1%}, Validation Accuracy: {2:>6.1%}, Validation Loss: {3:.3f}"
                print(msg.format(epoch + 1, acc, val_acc, val_loss))

                # show_progress(epoch, feed_dict_tr, feed_dict_val, val_loss)
                saver.save(session, './classifier')

            self.total_iterations += num_iteration
'''
    def load_test(self, test_path, img_size, classes):

        for class_name in classes:
            path = os.path.join(test_path, class_name, '*g')
            files = sorted(glob.glob(path))

            xtest = []
            xtestID = []
            print("Reading test images")
            for fl in files:
                flbase = os.path.basename(fl)
                print(fl)
                img = cv2.imread(fl)
                img = cv2.resize(img, (img_size, img_size), cv2.INTER_LINEAR)
            X_test.append(img)
            xtestID.append(flbase)

            # Normalization
            xtest = np.array(xtest, dtype=np.uint8)
            xtest = xtest.astype('float32')
            xtest = xtest / 255

            return xtest, xtestID
'''
session = tf.Session()
'''
        x = tf.placeholder(tf.float32, shape={None, self.img_size}, name='x')
        x_image = tf.reshape(x, [-1, img_size, img_size, num_channels])

        y_true = tf.placeholder(tf.float32, shape=[None, num_classes], name='y_true')
        y_true_cls = tf.argmax(y_true, dimension=1)

        layer_conv1, weights_conv1 = \
            new_conv_layer(input=x_image, num_input_channels=num_channels, filter_size=filter_size1, num_filters=num_filters1, use_pooling=True)

        # print("now layer2 input")
        # print(layer_conv1.get_shape())
        layer_conv2, weights_conv2 = \
            new_conv_layer(input=layer_conv1, num_input_channels=num_filters1, filter_size=filter_size2, num_filters=num_filters2, use_pooling=True)

        # print("now layer3 input")
        # print(layer_conv2.get_shape())
        layer_conv3, weights_conv3 = \
            new_conv_layer(input=layer_conv2, num_input_channels=num_filters2, filter_size=filter_size3, num_filters=num_filters3, use_pooling=True)

        # print("now layer flatten input")
        # print(layer_conv3.get_shape())
        layer_flat, num_features = flatten_layer(layer_conv3)

        layer_fc1 = new_fc_layer(input=layer_flat,num_inputs=num_features, num_outputs=fc_size, use_relu=True)

        layer_fc2 = new_fc_layer(input=layer_fc1, num_inputs=fc_size, num_outputs=num_classes, use_relu=False)

        y_pred = tf.nn.softmax(layer_fc2)

        y_pred_cls = tf.argmax(y_pred, dimension=1)
        cross_entropy = tf.nn.softmax_cross_entropy_with_logits(logits=layer_fc2, labels=y_true)
        cost = tf.reduce_mean(cross_entropy)
'''
# ------ Prediction ------ #

# First, pass the path of the image
def prediction(self, image_path):
    dir_path = os.path.dirname(os.path.realpath(__file__))
    filename = dir_path + '/' + image_path
    img_size = 128
    num_channels = 3
    images = []

    # Reading the image using OpenCV
    image = cv2.imread(filename)

    # Resizing the image to our desired size and preprocessing will be done exactly as done during training
    image = cv2.resize(image, (img_size, img_size), 0, 0, cv2.INTER_LINEAR)
    images.append(image)
    images = np.array(images, dtype=np.uint8)
    images = images.astype('float32')
    images = np.multiply(images, 1.0/255.0)

    # The input to the network is of shape [None img_size img_size num_channels]. Hence we reshape.
    x_batch = images.reshape(1, img_size, img_size, num_channels)

    # Let us restore the saved model
    sess = tf.Session()
    # Step-1: Recreate the network graph. At this step only graph is created.
    saver = tf.train.import_meta_graph('Classifier.meta')
    # Step-2: Now let's load the weights saved using the restore method.
    saver.restore(sess, tf.train.latest_checkpoint('./'))

    # Accessing the default graph which we have restored
    graph = tf.get_default_graph()

    # Now, let's get hold of the op that we can be processed to get the output.
    # In the original network y_pred is the tensor that is the prediction of the network
    y_pred = graph.get_tensor_by_name("y_pred:0")

    # Let's feed the images to the input placeholders
    x = graph.get_tensor_by_name("x:0")
    y_true = graph.get_tensor_by_name("y_true:0")
    y_test_images = np.zeros((1, 2))


    # Creating the feed_dict that is required to be fed to calculate y_pred
    feed_dict_testing = {x: x_batch, y_true: y_test_images}
    result = sess.run(y_pred, feed_dict=feed_dict_testing)

    print(result)


'''
    if __name__ == '__main__':
        Classify = Classifier('cat-dog-training_data', batch_size=32)
        Classify.train(2000)
        Classify.predict('dog.jpg')
'''
