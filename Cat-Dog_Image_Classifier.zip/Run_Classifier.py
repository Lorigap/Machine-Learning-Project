from Classifier import *

test = Classifier('training_data', batch_size=32)
test.train(800)
test.prediction('dog.jpg')
