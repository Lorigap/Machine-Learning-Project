'''Imports CIFAR-10 data.'''

import numpy as np
import pickle
import sys
from random import shuffle

# Data iterator class that allows for easy batching to our algorithm

class DataIterator():
  def __init__(self, dataset):
      self.dataset = dataset
      self.size = len(self.dataset)
      self.epochs = 0
      self.shuffle()

  def shuffle(self):
      shuffle(self.dataset) 
      self.cursor = 0

  def epoch(self):
    self.epochs += 1
    self.shuffle()

  def next_batch(self, n):
      if self.cursor+n > self.size:
        self.epoch()
      res = self.dataset[self.cursor:self.cursor+n]
      self.cursor += n

      data, labels = map(list, zip(*res))

      return data, labels

# Simple import function for CIFAR10 dataset
# https://github.com/wolfib/image-classification-CIFAR10-tf

# loads data from a cifar10 file

def load_CIFAR10_batch(filename):

  with open(filename, 'rb') as f:
    if sys.version_info[0] < 3:
      dict = pickle.load(f)
    else:
      dict = pickle.load(f, encoding='latin1')
    x = dict['data']
    y = dict['labels']
    x = x.astype(float)
    y = np.array(y)
  return x, y

def load_data():

  xs = []
  ys = []
  for i in range(1, 6):
    filename = 'cifar-10-batches-py/data_batch_' + str(i)
    X, Y = load_CIFAR10_batch(filename)
    xs.append(X)
    ys.append(Y)

  x_train = np.concatenate(xs)
  y_train = np.concatenate(ys)
  del xs, ys

  print (x_train, "X- train")
  print (y_train, "Y- train")

  x_test, y_test = load_CIFAR10_batch('cifar-10-batches-py/test_batch')

  classes = ['plane', 'car', 'bird', 'cat', 'deer', 'dog', 'frog', 'horse',
    'ship', 'truck']

  # we turn our labels into one hot vector encoding
  # where a len(classes) vector of zeros holds a value of one on index of its class

  one_hot_vectors = np.eye(len(classes))

  y_train_one_hot = []
  y_test_one_hot = []

  for label in y_train:
    y_train_one_hot.append(np.array(one_hot_vectors[y_train[label]]))

  for label in y_test:
    y_test_one_hot.append(np.array(one_hot_vectors[y_test[label]])) 

  # # Normalize Data
  # mean_image = np.mean(x_train, axis=0)
  # x_train -= mean_image
  # x_test -= mean_image

  x_train = convert_images(x_train) 
  x_test = convert_images(x_test)


  train = list([list(a) for a in zip(x_train, y_train_one_hot)])
  test = list([list(a) for a in zip(x_test, y_test_one_hot)])

  shuffle(train)
  shuffle(test)

  data_dict = {
    'train': DataIterator(train),
    'test': DataIterator(test),
    'classes': classes
  }

  return data_dict

def convert_images(data):
    data_float = np.array(data, dtype=float) / 255.0
    
    images = data_float.reshape([-1, 3, 32, 32])
    images = images.transpose([0, 2, 3, 1])

    return images