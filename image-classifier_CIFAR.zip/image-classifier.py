# CIFAR 10 dataset: https://www.cs.toronto.edu/~kriz/cifar.html

import datautilities as du
import tensorflow as tf
import numpy as np

# empty variable holding weights for layer
def create_weights(shape):
    return tf.Variable(tf.truncated_normal(shape, stddev=0.05))

# empty variable holding biases for layer
def create_biases(size):
    return tf.Variable(tf.constant(0.05, shape=[size]))


def create_convolutional_layer(input, num_input_channels, conv_filter_size, num_filters):
    # we create weights and biases that will be used to train our layer
    weights = create_weights(shape=[conv_filter_size, conv_filter_size, num_input_channels, num_filters])
    biases = create_biases(num_filters)

    # convolutional layer
    layer = tf.nn.conv2d(input=input, filter=weights, strides=[1, 1, 1, 1], padding='SAME')
    layer += biases
    
    layer = tf.nn.max_pool(value=layer, ksize=[1, 2, 2, 1], strides=[1, 2, 2, 1], padding='SAME')

    ## Output of pooling is fed to Relu which is the activation function for us.
    layer = tf.nn.relu(layer)

    return layer

def create_flatten_layer(layer):
    
    layer_shape = layer.get_shape()

    # Number of features will be img_height * img_width* num_channels.
    num_features = layer_shape[1:4].num_elements()
    ## Now, we Flatten the layer so we shall have to reshape to num_features
    layer = tf.reshape(layer, [-1, num_features])

    return layer

def create_fc_layer(input, num_inputs, num_outputs, use_relu=True):
    #Let's define trainable weights and biases.
    weights = create_weights(shape=[num_inputs, num_outputs])
    biases = create_biases(num_outputs)
    # Fully connected layer takes input x and produces wx+b.Since, these are matrices, we use matmul function in Tensorflow
    layer = tf.matmul(input, weights) + biases
    if use_relu:
        layer = tf.nn.relu(layer)

    return layer

class ImageClassifier(object):

    def __init__(self, num_classes, image_size=32):
        self.image_size = image_size
        self.num_classes = num_classes
        self.num_channels = 3

    def build_graph(self):
        # Input placeholder in data graph

        self.data = tf.placeholder(tf.float32, shape=[None, self.image_size,self.image_size, self.num_channels], name='data')

        # CNN - Convolutional Neural Network
        print (self.data)
        layer_conv1 = create_convolutional_layer(self.data, self.num_channels, 3, 32)
        print (layer_conv1)
        layer_conv2 = create_convolutional_layer(layer_conv1, 32, 3, 32)
        print (layer_conv2)
        layer_conv3= create_convolutional_layer(layer_conv2, 32, 3, 64)
        print (layer_conv3)
        layer_flat = create_flatten_layer(layer_conv3)
        print (layer_flat)
        layer_fc1 = create_fc_layer(layer_flat, layer_flat.get_shape()[1:4].num_elements(), 128, True)
        print (layer_fc1)
        logits = create_fc_layer(layer_fc1, 128, self.num_classes, False)

        print (logits)

        # Output placeholder in data graph

        self.target = tf.placeholder(tf.float32, shape=[None, self.num_classes], name='target')

        target_class = tf.argmax(self.target, axis=1)

        print (target_class)

        prediction = tf.nn.softmax(logits)

        print (prediction)
        prediction_class = tf.argmax(prediction, axis=1)
        print (prediction_class)

        # error function, this is being minimized by optimizer

        self.error = tf.reduce_mean(tf.nn.softmax_cross_entropy_with_logits_v2(logits=logits,labels=self.target))

        # uses AdamOptimizer to minimize error function

        self.optimizer = tf.train.AdamOptimizer(learning_rate=5e-4).minimize(self.error)

        # measures accuracy between true and predicted classes

        self.accuracy = tf.reduce_mean(tf.cast(tf.equal(prediction_class, target_class), tf.float32))


if __name__ == '__main__':
    
    dataset = du.load_data()

    train_iterator = dataset['train']
    test_iterator = dataset['test']

    classifier = ImageClassifier(len(dataset['classes']))

    classifier.build_graph()

    session = tf.Session()

    session.run(tf.global_variables_initializer())

    saver = tf.train.Saver()

    for epoch in range(10):
        epoch_error = 0

        for step in range(100):
            train_data, train_target = train_iterator.next_batch(10)
            session.run(classifier.optimizer, {
                classifier.data: train_data, 
                classifier.target: train_target
            })
            epoch_error += session.run(classifier.error, {
                classifier.data: train_data, 
                classifier.target: train_target
            })

        train_iterator.epoch()

        epoch_error /= 100

        test_data, test_target = test_iterator.next_batch(test_iterator.size)
        
        valid_error = session.run(classifier.error, {
            classifier.data: test_data,
            classifier.target: test_target
        })

        valid_accuracy = session.run(classifier.accuracy, {
            classifier.data: test_data,
            classifier.target: test_target
        })

        print("Epoch %d, train error: %.2f, valid accuracy: %.1f %%" % (epoch, epoch_error, valid_accuracy * 100.0))

        saver.save(session, './image_classifier')
